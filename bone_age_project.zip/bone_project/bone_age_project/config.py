import os

class ProjectConfig:
    # --- DYNAMIC PATHS (Production Grade) ---
    # 1. Get the folder where this code (config.py) lives
    baseCodeDir = os.path.dirname(os.path.abspath(__file__))
    
    # 2. Point to the 'bonedata' folder inside that directory
    datasetPath = os.path.join(baseCodeDir, 'bonedata')
    
    # --- AUTO-GENERATED PATHS ---
    # These assume your 'bonedata' folder has the standard Kaggle structure inside:
    # bonedata/
    #    ├── boneage-training-dataset.csv
    #    └── boneage-training-dataset/
    #           └── boneage-training-dataset/ (images)
    
    trainCsvPath = os.path.join(datasetPath, 'boneage-training-dataset.csv')
    
    # Note: Kaggle datasets often have double nested folders. 
    # If your images are directly in 'bonedata/images', change this line accordingly.
    trainImagesPath = os.path.join(datasetPath, 'boneage-training-dataset', 'boneage-training-dataset')
    
    # --- OUTPUTS ---
    outputDir = os.path.join(baseCodeDir, "project_outputs")
    modelSavePath = os.path.join(outputDir, "best_bone_age_model.keras")
    historyLogPath = os.path.join(outputDir, "training_log.csv")
    
    # --- HYPERPARAMETERS ---
    seed = 42
    imageSize = 256
    batchSize = 16  # Safe for most local GPUs (RTX 3060/4060)
    epochs = 20
    learningRate = 0.0001
    
    # --- CLASSIFICATION CATEGORIES ---
    ageCategories = {
        'Child': (0, 120),
        'Adolescent': (120, 192),
        'Young Adult': (192, 300)
    }

# Create output directory if it doesn't exist
if not os.path.exists(ProjectConfig.outputDir):
    os.makedirs(ProjectConfig.outputDir)