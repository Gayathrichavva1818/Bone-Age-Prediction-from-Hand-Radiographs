import os
import cv2
import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from config import ProjectConfig

class MultiOutputDataGenerator(tf.keras.utils.Sequence):
    def __init__(self, df, x_col, y_col_regr, y_col_class, gender_col, batch_size, target_size, is_training=True):
        super().__init__()
        self.df = df.copy()
        self.x_col = x_col
        self.y_col_regr = y_col_regr
        self.y_col_class = y_col_class
        self.gender_col = gender_col
        self.batch_size = batch_size
        self.target_size = target_size
        self.is_training = is_training
        self.indices = np.arange(len(self.df))
        
        # CLAHE (Contrast Limited Adaptive Histogram Equalization)
        # This makes bone structures pop out in X-rays
        self.clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        self.class_map = {'Child': 0, 'Adolescent': 1, 'Young Adult': 2}
        
        self.datagen = tf.keras.preprocessing.image.ImageDataGenerator(
            rotation_range=20,
            width_shift_range=0.1,
            height_shift_range=0.1,
            horizontal_flip=True,
            fill_mode='nearest'
        ) if is_training else tf.keras.preprocessing.image.ImageDataGenerator()

    def __len__(self):
        return int(np.ceil(len(self.df) / self.batch_size))
        
    def apply_clahe_processing(self, img_path):
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is None: return np.zeros((self.target_size[0], self.target_size[1], 3))
        
        img = cv2.resize(img, self.target_size)
        img = self.clahe.apply(img)
        img_rgb = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)
        return img_rgb

    def __getitem__(self, index):
        batch_indices = self.indices[index * self.batch_size:(index + 1) * self.batch_size]
        batch_df = self.df.iloc[batch_indices]

        images = np.zeros((len(batch_df), *self.target_size, 3), dtype=np.float32)
        genders = np.array(batch_df[self.gender_col].values, dtype=np.float32)
        ages = np.array(batch_df[self.y_col_regr].values, dtype=np.float32)
        
        age_classes = np.zeros((len(batch_df), 3), dtype=np.float32)
        for i, cat in enumerate(batch_df[self.y_col_class].values):
            age_classes[i, self.class_map[cat]] = 1.0

        for i, path in enumerate(batch_df[self.x_col].values):
            try:
                img_arr = self.apply_clahe_processing(path)
                img_arr = img_arr.astype(np.float32) / 255.0 
                if self.is_training:
                    img_arr = self.datagen.random_transform(img_arr)
                images[i] = img_arr
            except Exception as e:
                pass

        return {'image_input': images, 'gender_input': genders}, {'age_output': ages, 'class_output': age_classes}

    def on_epoch_end(self):
        if self.is_training:
            np.random.shuffle(self.indices)

def get_data_generators():
    print("------------------------------------------------")
    print("🔄 INITIALIZING DATA PIPELINE...")
    print(f"📂 Looking for dataset at: {ProjectConfig.datasetPath}")
    
    # 1. Load CSV
    if not os.path.exists(ProjectConfig.trainCsvPath):
        raise FileNotFoundError(f"❌ CRITICAL ERROR: CSV not found at {ProjectConfig.trainCsvPath}")
        
    rawDataFrame = pd.read_csv(ProjectConfig.trainCsvPath)
    print(f"✅ CSV Loaded Successfully. Total Entries: {len(rawDataFrame)}")
    
    # 2. Normalize Columns
    rawDataFrame.rename(columns={'boneage': 'boneAge', 'male': 'isMale'}, inplace=True)
    
    # 3. Helpers
    def generateFilePaths(idValue):
        # We assume the ID matches the filename
        return os.path.join(ProjectConfig.trainImagesPath, f"{idValue}.png")

    def categorizeAge(months):
        if months <= ProjectConfig.ageCategories['Child'][1]: return 'Child'
        elif months <= ProjectConfig.ageCategories['Adolescent'][1]: return 'Adolescent'
        return 'Young Adult'

    # 4. Feature Engineering
    rawDataFrame['imagePath'] = rawDataFrame['id'].apply(generateFilePaths)
    rawDataFrame['ageCategory'] = rawDataFrame['boneAge'].apply(categorizeAge)
    rawDataFrame['genderEncoded'] = rawDataFrame['isMale'].apply(lambda x: 1 if x else 0)
    
    # Quick sanity check: Does the first image actually exist?
    first_img_path = rawDataFrame['imagePath'].iloc[0]
    if not os.path.exists(first_img_path):
        print(f"⚠️ WARNING: Could not find image at {first_img_path}")
        print("   Please check your 'trainImagesPath' in config.py")
    else:
        print(f"✅ Image Path Verification Passed (Found: {first_img_path})")

    # 5. Split Data (70% Train, 15% Val, 15% Test)
    trainVal, testData = train_test_split(rawDataFrame, test_size=0.15, random_state=ProjectConfig.seed, stratify=rawDataFrame['ageCategory'])
    trainData, valData = train_test_split(trainVal, test_size=0.1765, random_state=ProjectConfig.seed, stratify=trainVal['ageCategory'])

    # --- FEEDBACK SUMMARY ---
    print("\n📊 DATASET STATISTICS:")
    print(f"   🔹 Training Set:   {len(trainData)} images")
    print(f"   🔹 Validation Set: {len(valData)} images")
    print(f"   🔹 Test Set:       {len(testData)} images")
    print(f"   🔹 Total Used:     {len(trainData) + len(valData) + len(testData)}")
    print("------------------------------------------------\n")

    # 6. Create Generators
    trainGen = MultiOutputDataGenerator(trainData, 'imagePath', 'boneAge', 'ageCategory', 'genderEncoded', 
                                        ProjectConfig.batchSize, (ProjectConfig.imageSize, ProjectConfig.imageSize), True)
    valGen = MultiOutputDataGenerator(valData, 'imagePath', 'boneAge', 'ageCategory', 'genderEncoded', 
                                      ProjectConfig.batchSize, (ProjectConfig.imageSize, ProjectConfig.imageSize), False)
    testGen = MultiOutputDataGenerator(testData, 'imagePath', 'boneAge', 'ageCategory', 'genderEncoded', 
                                       ProjectConfig.batchSize, (ProjectConfig.imageSize, ProjectConfig.imageSize), False)
    
    return trainGen, valGen, testGen, testData