import os
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import tensorflow as tf
import cv2
from sklearn.metrics import (confusion_matrix, classification_report, mean_absolute_error, 
                             mean_squared_error, r2_score, cohen_kappa_score)
from config import ProjectConfig
from data_loader import get_data_generators

# --- 1. GRAD-CAM FUNCTION (The "Visual Explanation" Requirement) ---
def make_gradcam_heatmap(img_array, model, last_conv_layer_name="conv5_block32_2_conv"):
    # Create a model that maps the input image to the activations of the last conv layer
    # AND the output predictions
    grad_model = tf.keras.models.Model(
        inputs=model.inputs, # [image_input, gender_input]
        outputs=[model.get_layer(last_conv_layer_name).output, model.output[0]] # output[0] is age regression
    )

    with tf.GradientTape() as tape:
        # Cast input to float32 to ensure compatibility
        inputs = [tf.cast(img_array[0], tf.float32), tf.cast(img_array[1], tf.float32)]
        conv_outputs, predictions = grad_model(inputs)
        loss = predictions[:, 0]

    # Compute gradients
    grads = tape.gradient(loss, conv_outputs)
    pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

    # Multiply each channel in the feature map array by 'how important this channel is'
    conv_outputs = conv_outputs[0]
    heatmap = conv_outputs @ pooled_grads[..., tf.newaxis]
    heatmap = tf.squeeze(heatmap)

    # Normalize the heatmap
    heatmap = tf.maximum(heatmap, 0) / tf.math.reduce_max(heatmap)
    return heatmap.numpy()

def save_gradcam(model, test_gen, save_dir):
    print("Generating Grad-CAM Heatmaps...")
    # Get a batch of data
    inputs, _ = test_gen.__getitem__(0) # Get first batch
    images = inputs['image_input']
    genders = inputs['gender_input']
    
    # We will generate heatmaps for the first 5 images in the batch
    plt.figure(figsize=(20, 8))
    for i in range(5):
        # Prepare single input
        img_input = np.expand_dims(images[i], axis=0)
        gender_input = np.expand_dims(genders[i], axis=0)
        
        # Generate Heatmap
        # Note: 'conv5_block32_2_conv' is the last conv layer in DenseNet169
        try:
            heatmap = make_gradcam_heatmap([img_input, gender_input], model, "conv5_block32_2_conv")
            
            # Resize heatmap to image size
            heatmap = cv2.resize(heatmap, (ProjectConfig.imageSize, ProjectConfig.imageSize))
            heatmap = np.uint8(255 * heatmap)
            heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
            
            # Superimpose
            original_img = np.uint8(255 * images[i])
            # Convert RGB to BGR for OpenCV
            original_img = cv2.cvtColor(original_img, cv2.COLOR_RGB2BGR) 
            
            superimposed_img = cv2.addWeighted(original_img, 0.6, heatmap, 0.4, 0)
            superimposed_img = cv2.cvtColor(superimposed_img, cv2.COLOR_BGR2RGB)
            
            # Plot
            plt.subplot(1, 5, i+1)
            plt.imshow(superimposed_img)
            plt.title(f"Sample {i+1}")
            plt.axis('off')
        except Exception as e:
            print(f"Could not generate Grad-CAM for sample {i}: {e}")
            
    plt.savefig(os.path.join(save_dir, "gradcam_analysis.png"))
    plt.close()

# --- 2. MAIN EVALUATION LOGIC ---
def evaluate_full():
    # Load
    print("Loading Data...")
    _, _, testGen, testDf = get_data_generators()
    print("Loading Model...")
    model = tf.keras.models.load_model(ProjectConfig.modelSavePath)
    
    # Predict
    print("Running Predictions...")
    preds = model.predict(testGen, verbose=1)
    pred_ages = preds[0].flatten()
    pred_classes = np.argmax(preds[1], axis=1)
    
    true_ages = testDf['boneAge'].values
    class_map = {'Child': 0, 'Adolescent': 1, 'Young Adult': 2}
    true_classes = testDf['ageCategory'].map(class_map).values
    
    # --- METRICS CALCULATION (Filling the Gaps) ---
    mae = mean_absolute_error(true_ages, pred_ages)
    rmse = np.sqrt(mean_squared_error(true_ages, pred_ages)) # RMSE 
    r2 = r2_score(true_ages, pred_ages) # R2 
    kappa = cohen_kappa_score(true_classes, pred_classes, weights='quadratic') # QWK 
    
    # --- GENDER BIAS ANALYSIS  ---
    male_indices = testDf['genderEncoded'] == 1
    female_indices = testDf['genderEncoded'] == 0
    
    mae_male = mean_absolute_error(true_ages[male_indices], pred_ages[male_indices])
    mae_female = mean_absolute_error(true_ages[female_indices], pred_ages[female_indices])
    
    # --- REPORT GENERATION ---
    report_text = f"""
    FINAL PRODUCTION GRADE REPORT
    -----------------------------
    1. REGRESSION METRICS:
       MAE (Mean Absolute Error): {mae:.4f} months
       RMSE (Root Mean Sq Error): {rmse:.4f} months
       R-Squared Score:           {r2:.4f}
    
    2. CLASSIFICATION METRICS:
       Quadratic Weighted Kappa:  {kappa:.4f}
       
    3. BIAS ANALYSIS (Gender):
       MAE (Males):   {mae_male:.4f}
       MAE (Females): {mae_female:.4f}
       Diff:          {abs(mae_male - mae_female):.4f}
       
    4. DETAILED CLASSIFICATION REPORT:
    {classification_report(true_classes, pred_classes, target_names=class_map.keys())}
    """
    
    print(report_text)
    with open(os.path.join(ProjectConfig.outputDir, "final_metrics_report.txt"), "w") as f:
        f.write(report_text)

    # --- PLOTS ---
    # 1. Confusion Matrix
    plt.figure(figsize=(8, 6))
    cm = confusion_matrix(true_classes, pred_classes)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', xticklabels=class_map.keys(), yticklabels=class_map.keys())
    plt.title('Confusion Matrix')
    plt.savefig(os.path.join(ProjectConfig.outputDir, "confusion_matrix.png"))
    plt.close()
    
    # 2. Scatter Plots
    plt.figure(figsize=(14, 6))
    plt.subplot(1, 2, 1)
    sns.scatterplot(x=true_ages, y=pred_ages, hue=testDf['genderEncoded'], palette='coolwarm', alpha=0.6)
    plt.plot([min(true_ages), max(true_ages)], [min(true_ages), max(true_ages)], 'r--')
    plt.title(f'Predicted vs Actual (R2: {r2:.2f})')
    
    plt.subplot(1, 2, 2)
    sns.scatterplot(x=true_ages, y=pred_ages - true_ages, hue=testDf['genderEncoded'], palette='coolwarm', alpha=0.6)
    plt.axhline(0, color='black', linestyle='--')
    plt.title('Residuals (Bias Check)')
    plt.savefig(os.path.join(ProjectConfig.outputDir, "regression_plots.png"))
    plt.close()
    
    # 3. GRAD-CAM (Visual Explanation)
    try:
        save_gradcam(model, testGen, ProjectConfig.outputDir)
    except Exception as e:
        print(f"Skipping Grad-CAM due to architecture mismatch or error: {e}")

if __name__ == "__main__":
    evaluate_full()