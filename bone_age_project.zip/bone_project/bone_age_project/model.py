import tensorflow as tf
from config import ProjectConfig

def createMultiModalModel():
    # 1. Image Branch
    image_input = tf.keras.layers.Input(shape=(ProjectConfig.imageSize, ProjectConfig.imageSize, 3), name='image_input')
    base_model = tf.keras.applications.DenseNet169(weights='imagenet', include_top=False, input_tensor=image_input)
    
    for layer in base_model.layers[:100]:
        layer.trainable = False
        
    x = tf.keras.layers.GlobalAveragePooling2D()(base_model.output)
    x = tf.keras.layers.Dropout(0.5)(x)
    
    # 2. Gender Branch
    gender_input = tf.keras.layers.Input(shape=(1,), name='gender_input')
    
    # 3. Fusion
    merged = tf.keras.layers.Concatenate()([x, gender_input])
    
    x = tf.keras.layers.Dense(1024, activation='relu')(merged)
    x = tf.keras.layers.Dropout(0.4)(x)
    x = tf.keras.layers.Dense(512, activation='relu')(x)
    
    # 4. Outputs
    age_output = tf.keras.layers.Dense(1, activation='linear', name='age_output')(x)
    class_output = tf.keras.layers.Dense(3, activation='softmax', name='class_output')(x)
    
    model = tf.keras.models.Model(inputs=[image_input, gender_input], outputs=[age_output, class_output])
    
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=ProjectConfig.learningRate),
        loss={'age_output': 'mae', 'class_output': 'categorical_crossentropy'},
        loss_weights={'age_output': 1.0, 'class_output': 0.5},
        metrics={'age_output': ['mae'], 'class_output': ['accuracy']}
    )
    
    return model