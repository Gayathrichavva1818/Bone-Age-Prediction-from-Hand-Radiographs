import matplotlib.pyplot as plt
import pandas as pd
import os
import tensorflow as tf
from config import ProjectConfig
from data_loader import get_data_generators
from model import createMultiModalModel

def plot_and_save_history(history):
    fig, axes = plt.subplots(1, 3, figsize=(20, 5))
    
    # Loss
    axes[0].plot(history.history['loss'], label='Train')
    axes[0].plot(history.history['val_loss'], label='Val')
    axes[0].set_title('Total Loss')
    axes[0].legend()
    
    # MAE
    axes[1].plot(history.history['age_output_mae'], label='Train')
    axes[1].plot(history.history['val_age_output_mae'], label='Val')
    axes[1].set_title('Regression MAE (Months)')
    axes[1].legend()
    
    # Accuracy
    axes[2].plot(history.history['class_output_accuracy'], label='Train')
    axes[2].plot(history.history['val_class_output_accuracy'], label='Val')
    axes[2].set_title('Classification Accuracy')
    axes[2].legend()
    
    save_path = os.path.join(ProjectConfig.outputDir, "training_history_plot.png")
    plt.savefig(save_path)
    print(f"Training plots saved to: {save_path}")
    plt.close()

if __name__ == "__main__":
    # 1. Get Data
    trainGen, valGen, _, _ = get_data_generators()
    
    # 2. Get Model
    model = createMultiModalModel()
    
    # 3. Callbacks (Saves Everything)
    checkpoint = tf.keras.callbacks.ModelCheckpoint(ProjectConfig.modelSavePath, monitor='val_loss', save_best_only=True, verbose=1)
    early_stop = tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    reduce_lr = tf.keras.callbacks.ReduceLROnPlateau(monitor='val_loss', factor=0.2, patience=3, verbose=1)
    csv_logger = tf.keras.callbacks.CSVLogger(ProjectConfig.historyLogPath, append=True)
    
    # 4. Train
    print("Starting Training...")
    history = model.fit(
        trainGen,
        validation_data=valGen,
        epochs=ProjectConfig.epochs,
        callbacks=[checkpoint, early_stop, reduce_lr, csv_logger],
    )
    
    # 5. Save Results
    plot_and_save_history(history)